filmes = [[], [], [], [], []]

def cadastro():
    filme = str(input("Filme:"))
    genero = str(input("Gênero:"))
    data = float(input("Data de lançamento: "))
    nota = float(input("Nota do filme:"))

    filmes[0].append(filme)s
    filmes[1].append(genero)
    filmes[2].append(data)
    filmes[3].append(nota)

    if nota > 7:
        filmes[4].append('Amo muito vey')
    elif nota == 7 :
        filmes[4].append("Mediano né vey")
    elif nota < 7 :
     filmes[4].append("Cruzes, odiei!")

     print("Cadastramos seu filme, divo(a)")

  

def lista():
    if len(filmes[0])==0:
        print("Não há filmes cadastrados.")
    else:
        for i in range(len(filmes[0])):
            print(f'{i + 1}. filme {filmes [0][i]}, genero {filmes [1][i]}, data {filmes [2][i]}, nota {filmes [3][i]}')

def buscar_filmes():
   pesquisa = input("digite o nome do filme")
   for i in range(len(filmes[0])):
       if pesquisa == filmes[0][i]:
           print(f'{i + 1}. filme {filmes [0][i]}, genero {filmes [1][i]}, data {filmes [2][i]}, nota {filmes [3][i]}')

def remover_filme():
    filmes_remover = input("Digite o nome do filme que deseja remover: ")
    for i in range(len(filmes)):
        if filmes_remover == filmes[0][i]:
            filmes[0].pop(i)
            filmes[1].pop(i)
            filmes[2].pop(i)
            filmes[3].pop(i)
            filmes[4].pop(i)

remover_filme()

def menu():
    while True():
        print(f"menu")
        print("1 - cadastrar filmes")
        print("2 - litar filmes")
        print("3 - buscar filmes")
        print("4 - remover filmes")
        print("5 - sair")
        opcao = input("escolha uma das opções: ")

        if opcao == "1":
            cadastro() 
        elif opcao == "2":
            lista()
        elif opcao == "3":
            buscar_filmes()
        elif opcao == "4":
            remover_filme()
        elif opcao == "5":
            print("Fechando programa...")
            break              
            #Amanda #Eduardo Amorim #Natalia #Pedro Gabriel
            

            




             
             
             
     


